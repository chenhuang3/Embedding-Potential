#!/bin/bash
#SBATCH --job-name=g.in
#SBATCH --nodes=1
#SBATCH --time=10:00:00
#SBATCH --mem=200G
#SBATCH --partition=ilahie
#SBATCH --account=ilahie
#SBATCH --ntasks-per-node=1

module load contrib/openmpi/3.0.0

ab=/gscratch/chem/hoyerc/Software/190816_epg_ZP-upd/abinit-7.10.4_epg/src/98_main/abinit

# debugging information
echo "**** Job Debugging Information ****"
echo "This job will run on $SLURM_JOB_NODELIST"
echo ""
echo "ENVIRONMENT VARIABLES"
set
echo "**********************************************" 

# copy last log file to another name
num=`ls -l g*.log | wc -l`
let "num += 1"
cp log $num.log

cd   $SLURM_SUBMIT_DIR

/gscratch/chem/hoyerc/Software/190816_epg_ZP-upd/dfet_epg/dfet   >  log &


cd   $SLURM_SUBMIT_DIR/subsys1/
mpirun -np 1  $ab < g.files  > log &
cd ..


cd   $SLURM_SUBMIT_DIR/subsys2/
mpirun -np 1  $ab < g.files  > log & 
cd ..

wait 
