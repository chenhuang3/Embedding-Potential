cd GetDen
rm *go* 
rm *ref*
cd ../
cd GetMag
rm *go* 
rm *ref*
cd ../
cd GetRhoa
rm *go* 
rm *ref*
cd ../
cd GetRhob
rm *go* 
rm *ref*
cd ../
cp go_DEN GetDen
cp go_DEN GetMag
cp go_DEN GetRhoa
cp go_DEN GetRhob
cd GetDen
./make_rho_xsf.sh &
cd ../
cd GetMag
./make_mag_xsf.sh &
cd ../
cd GetRhoa
./make_rhoa_xsf.sh &
cd ../
cd GetRhob
./make_rhob_xsf.sh &
cd ../
