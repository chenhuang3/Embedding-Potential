#!/bin/bash
sed -i -e 's/\t\$.FCFLAGS. \\//' src/98_main/Makefile
