# Copyright (C) 1998-2014 ABINIT group (XG)
 sed -e 's&#CODE_PAR&$CODE_PAR&' Utilities/,perl_tmp > Utilities/,perl_location_command
