#!/bin/sh

./config/scripts/makemake --clean
