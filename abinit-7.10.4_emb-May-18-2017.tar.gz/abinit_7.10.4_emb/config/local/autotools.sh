# Autotools version information
abi_m4_version="010413"
abi_ac_version="026300"
abi_am_version="011101"
abi_lt_version="020206"
