#!/bin/sh

./config/scripts/makemake
