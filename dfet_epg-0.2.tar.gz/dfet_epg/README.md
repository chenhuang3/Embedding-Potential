# dfet_embpot_gen
Generating embedding potential
